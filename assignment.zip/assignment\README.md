# AI Agent Assignment - Prisma

## Overview
This project is a state-of-the-art **Multi-Agent Investment Research System** named **Prisma** that generates institutional-grade equity research reports on demand. It features a real-time, interactive dashboard UI that displays live agent progress streaming via Server-Sent Events (SSE), beautiful financial charts, and historical report archiving.

### Main Features
*   **Multi-Agent Research Pipeline**: Built on **LangGraph.js**, featuring parallel research agents (Financials, News, Risks, Competitors, Growth) that execute concurrently and feed into a decision-making agent.
*   **Real-time SSE Progress Streaming**: Server-Sent Events stream intermediate agent states and logs directly from the backend graph execution to the React frontend.
*   **Fortress UI / UX**: A premium dark-mode, glassmorphism-styled web app utilizing Next.js, Tailwind CSS, Framer Motion, and Recharts.
*   **Data Integrations**: Real-time stock data fetching via Yahoo Finance API (`yahoo-finance2`) and deep web searching using Tavily API.
*   **Supabase Database & Auth**: Analyst account registration, session tracking, and secure database persistence of all generated reports.
*   **Fallback Local Storage**: Full functionality fallback using client-side storage if Supabase credentials are not configured.

---

## How to Run

### Python version
*   **Python Version**: N/A (Built entirely using **Node.js (v18+)** and **TypeScript/JavaScript**).
*   Using Node.js instead of Python allows a unified, single-process codebase where the multi-agent graph runs directly in the Next.js API route, enabling seamless, low-latency Server-Sent Events (SSE) streaming of agent states to the React dashboard.

### Installation
1.  Navigate into the source code directory:
    ```bash
    cd src
    ```
2.  Install the required dependencies using npm:
    ```bash
    npm install
    ```

### Environment Variables
Create a `.env.local` or `.env` file in the root of the `src/` directory. You can use the provided `.env.example` as a template:
```env
# Google Gemini API Key (obtained from Google AI Studio)
GEMINI_API_KEY=your_gemini_api_key_here

# Tavily Web Search API Key (obtained from tavily.com)
TAVILY_API_KEY=your_tavily_api_key_here

# Supabase Configuration (Optional - falling back to LocalStorage if empty)
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key_here
SUPABASE_PASSWORD=your_supabase_db_password_here
```

### Running Commands
To spin up the local Next.js development server:
```bash
npm run dev
```
Once started, navigate to [http://localhost:3000](http://localhost:3000) in your web browser.

To build the application for production:
```bash
npm run build
npm run start
```

---

## Architecture

### Overall Workflow
The multi-agent execution follows a structured, directed acyclic graph (DAG) implemented in LangGraph.js:
1.  **START** ➔ **Company Research Node**: Extracts ticker and searches general business background.
2.  **Tier 1 Research (Parallel)**:
    *   **Financials Agent**: Pulls historical quotes, statistics, and income statements.
    *   **News Agent**: Conducts Tavily searches for recent press releases and market sentiment.
    *   **Competitor Agent**: Maps peer groups and performs benchmarking.
3.  **Tier 2 Research (Data Dependencies Resolved)**:
    *   **Growth Agent**: Processes financials to compute growth rates, margins, and valuation metrics.
    *   **Risk Agent**: Analyzes news and financials to assess operational and market risks.
4.  **Decision-Making**:
    *   **Investment Decision Agent**: Aggregates all gathered intelligence to formulate a recommendation (Buy, Sell, Hold), rating, and investment thesis.
5.  **Report Generation**:
    *   **Report Generator Agent**: Compiles the final institutional-grade research report in Markdown.
6.  **END**

```
                     [START]
                        │
                        ▼
              [Company Research Node]
                        │
         ┌──────────────┼──────────────┐ (Parallel Fan-Out)
         ▼              ▼              ▼
    [Financials]     [News]      [Competitors]
         │              │              │
         ▼              ▼              │
      [Growth]       [Risks]           │
         │              │              │
         └──────────────┼──────────────┘ (Parallel Fan-In)
                        ▼
             [Investment Decision]
                        │
                        ▼
               [Report Generator]
                        │
                        ▼
                      [END]
```

### Components
*   **Web Dashboard UI**: Multi-tab layout showcasing:
    *   *Search/Command bar* to initiate analyses.
    *   *Live execution logs* and progress bars.
    *   *Interactive financial charts* (prices, margins, revenues).
    *   *Formatted report viewer* supporting full markdown rendering.
*   **Next.js SSE Route Handler**: Initiates the LangGraph execution in a backend runtime, utilizing a customized callback progress hook to flush progress updates as Server-Sent Events (SSE) stream back to the UI.
*   **Supabase Schema**: A clean relational design containing:
    *   `users` table managed by Supabase Auth.
    *   `investment_reports` table linking analyst ID, ticker, name, verdict, score, summary, and markdown report text.

### LLM Used
*   **Google Gemini 2.5 Flash / Flash Lite**: Selected for its exceptionally fast response times, low latency, large context window (ideal for reading extensive financial results), and reliable structured output formatting.

### Tools Used
*   **Yahoo Finance API (`yahoo-finance2`)**: To query institutional market data, currency, stock prices, P/E multiples, and capitalization metrics.
*   **Tavily Search API**: Structured search engine designed specifically for LLM-agent web retrieval, optimizing competitor mapping and risk news scanning.

---

## Key Decisions & Trade-offs

### Why this Architecture
*   **Node.js / Next.js Stack**: Placing both the agent execution engine and the front-end dashboard under a single Next.js project allows us to easily use React state management alongside Server-Sent Events (SSE). It avoids serialization bottlenecks or cross-language network calls that are common in hybrid Python + JS setups.
*   **LangGraph.js DAG Design**: Creating a structured graph rather than an agentic "free-for-all" ensures deterministic flow, predictable token consumption, and reliable execution. Resolving data dependencies (e.g. financials must run before growth, news must run before risk) in an organized DAG guarantees high-quality analyses.

### Why this Model
*   **Gemini 2.5 Flash**: Offers the perfect balance of processing speed, large-context reasoning, and cost efficiency. For recursive agent loops, token latency is the primary bottleneck. Gemini 2.5 Flash returns responses in fractions of a second, ensuring a fast user experience.

### What wasn't Implemented
*   **Automated Portfolio Rebalancing**: Currently, the system provides recommendations but does not link with broker APIs to execute trades.
*   **Vector RAG over 10-K filings**: To keep analysis under 60 seconds, we rely on live Yahoo Finance and web queries rather than downloading and indexing 150-page PDF annual filings. This represents a trade-off of depth for speed and real-time execution.

---

## Example Runs
Below are summaries of the generated research reports. The full markdown reports are located in `outputs/`:

### Company A: Apple Inc. (AAPL)
*   **Verdict**: **BUY** (Confidence: 85%)
*   **Key Highlights**: Strong ecosystem loyalty with over 2.2B active devices; recurring high-margin Services revenue growing at 12%; anticipation of a hardware-accelerated "Apple Intelligence" super-cycle.
*   **Target Price Horizon**: 12 Months
*   **Report File**: [outputs/company_1.md](file:///assignment/outputs/company_1.md)

### Company B: Tesla Inc. (TSLA)
*   **Verdict**: **HOLD** (Confidence: 70%)
*   **Key Highlights**: Uncontested brand leadership in EV and Megapack energy storage, offset by compressing automotive margins (down to 14.6% due to pricing wars) and valuation premiums (trailing P/E > 80x).
*   **Target Price Horizon**: 12 Months
*   **Report File**: [outputs/company_2.md](file:///assignment/outputs/company_2.md)

### Company C: NVIDIA Corporation (NVDA)
*   **Verdict**: **STRONG BUY** (Confidence: 90%)
*   **Key Highlights**: Dominant 90%+ market share in AI accelerators; gross margins of 76% and net margins near 49%; Blackwell chip architecture demand exceeds supply; CUDA software provides massive developer switching costs.
*   **Target Price Horizon**: 12 Months
*   **Report File**: [outputs/company_3.md](file:///assignment/outputs/company_3.md)

---

## Improvements
*   **Multi-Company Benchmarking**: Implementing a comparative dashboard view that plots financial metrics (e.g. revenue growth vs margins) of multiple tickers side-by-side.
*   **Retrieval-Augmented Generation (RAG) over Earnings Call Transcripts**: Extracting tone and sentiment from CEO/CFO remarks by parsing official call recordings/transcripts.
*   **PDF Export**: Allowing analysts to download high-fidelity, branded PDF versions of the compiled equity research reports directly from the UI.

---

## LLM Chat Logs
As part of the development process, comprehensive transcripts mapping the pair-programming and planning sessions with the AI assistant have been compiled:
*   [LLM Chat Session 1: Supabase Integration & Account Dashboard](file:///assignment/llm_chat_logs/chat_01.md)
*   [LLM Chat Session 2: Assignment Packaging & Setup](file:///assignment/llm_chat_logs/chat_02.md)
